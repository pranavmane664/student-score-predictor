import json

import numpy as np
import pandas as pd

from src.data import (
    FEATURE_COLUMNS,
    REQUIRED_COLUMNS,
    clean_dataset,
    split_dataset,
    validate_dataset,
)
from src.evaluation import (
    build_predictions_dataframe,
    calculate_metrics,
    save_actual_vs_predicted_plot,
    save_example_prediction,
    save_metrics,
    save_predictions,
)
from src.model import build_pipeline, predict


def sample_dataframe() -> pd.DataFrame:
    rows = []
    for index in range(10):
        rows.append(
            {
                "student_id": f"TEST{index + 1:03d}",
                "study_hours_per_week": np.nan if index == 2 else 5 + index,
                "attendance_percentage": 70 + index * 2,
                "previous_exam_score": 55 + index * 3,
                "assignments_completed": 4 + index % 6,
                "sleep_hours": 6 + index * 0.1,
                "final_score": 58 + index * 3,
            }
        )
    return pd.DataFrame(rows)


def test_dataset_contains_all_required_columns():
    dataframe = sample_dataframe()
    validate_dataset(dataframe)
    assert list(dataframe.columns) == REQUIRED_COLUMNS


def test_duplicate_removal_works():
    dataframe = sample_dataframe()
    duplicated = pd.concat([dataframe, dataframe.iloc[[0]]], ignore_index=True)
    assert len(clean_dataset(duplicated)) == len(dataframe)


def test_feature_selection_excludes_identifier_and_target():
    X_train, X_test, *_ = split_dataset(sample_dataframe())
    assert list(X_train.columns) == FEATURE_COLUMNS
    assert list(X_test.columns) == FEATURE_COLUMNS
    assert "student_id" not in X_train.columns
    assert "final_score" not in X_train.columns


def test_split_uses_expected_feature_columns_and_sizes():
    X_train, X_test, y_train, y_test, train_ids, test_ids = split_dataset(
        sample_dataframe()
    )
    assert (len(X_train), len(X_test)) == (8, 2)
    assert len(y_train) == len(train_ids) == 8
    assert len(y_test) == len(test_ids) == 2


def test_pipeline_fits_with_missing_feature_values():
    dataframe = sample_dataframe()
    X_train, X_test, y_train, *_ = split_dataset(dataframe)
    pipeline = build_pipeline().fit(X_train, y_train)
    assert pipeline.named_steps["imputer"].strategy == "median"
    assert np.isfinite(predict(pipeline, X_test)).all()


def test_predictions_have_expected_length_and_numeric_values():
    dataframe = sample_dataframe()
    X_train, X_test, y_train, *_ = split_dataset(dataframe)
    predictions = predict(build_pipeline().fit(X_train, y_train), X_test)
    assert len(predictions) == len(X_test)
    assert np.issubdtype(predictions.dtype, np.number)


def test_metric_calculation_returns_finite_numbers():
    metrics = calculate_metrics([60, 70, 80], [62, 68, 79])
    assert set(metrics) == {"mae", "mse", "r2_score"}
    assert all(isinstance(value, float) for value in metrics.values())
    assert all(np.isfinite(value) for value in metrics.values())


def test_result_functions_create_expected_files(tmp_path):
    metrics_path = tmp_path / "metrics.json"
    predictions_path = tmp_path / "test_predictions.csv"
    example_path = tmp_path / "example_prediction.json"
    plot_path = tmp_path / "actual_vs_predicted.png"
    metrics = calculate_metrics([60, 70], [61, 68])
    rows = build_predictions_dataframe(["A", "B"], [60, 70], [61, 68])

    save_metrics(metrics, metrics_path)
    save_predictions(rows, predictions_path)
    save_example_prediction({column: 1 for column in FEATURE_COLUMNS}, 65.5, example_path)
    save_actual_vs_predicted_plot([60, 70], [61, 68], plot_path)

    assert json.loads(metrics_path.read_text())["mae"] == 1.5
    assert list(pd.read_csv(predictions_path).columns) == [
        "student_id",
        "actual_score",
        "predicted_score",
        "absolute_error",
    ]
    assert json.loads(example_path.read_text())["predicted_final_score"] == 65.5
    assert plot_path.stat().st_size > 0
