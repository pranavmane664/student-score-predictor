# Student Score Predictor

## Overview

Student Score Predictor is a Beginner Machine Learning Mini Project built with Python and scikit-learn. It demonstrates a reproducible, script-first regression workflow from loading a CSV through evaluation and saved result artifacts.

## Problem Statement

The project predicts a synthetic student's numeric final score from study-related numeric features. Because the target is continuous, this is a regression problem.

## Dataset

`data/student_scores.csv` is a fully synthetic dataset containing 150 rows. It contains no real students or personal data. Three duplicate rows and eight missing feature values are deliberately included for preprocessing practice.

## Features and Target

| Role | Columns |
| --- | --- |
| Features | `study_hours_per_week`, `attendance_percentage`, `previous_exam_score`, `assignments_completed`, `sleep_hours` |
| Target | `final_score` |
| Identifier | `student_id` (excluded from training) |

## Data Preprocessing

The workflow validates all required columns, rejects a missing target, removes exact duplicate rows, and performs an 80/20 train/test split with `random_state=42`. Missing feature values are filled using a median `SimpleImputer` inside the scikit-learn pipeline. The imputer and model are fitted only on training data, preventing information leakage from the test set.

## Machine Learning Workflow

```text
CSV -> Exploration -> Cleaning -> Train/Test Split -> Median Imputation
    -> Linear Regression -> Prediction -> Evaluation -> Result Files
```

## Model

The only model is Linear Regression, selected as a clear baseline for a Beginner regression project. No scaler is used because this scope focuses on missing-value handling and a simple linear baseline.

## Evaluation Metrics

Results from the latest verified execution:

| Metric | Value | Interpretation |
| --- | ---: | --- |
| MAE | 3.7417 | Average absolute prediction error. |
| MSE | 21.3937 | Squared-error metric that penalizes larger errors more strongly. |
| R² | 0.6274 | Proportion of target variance explained by the model; R² can be negative for a poor model. |

## Example Prediction

The required example uses 14 study hours per week, 92% attendance, previous exam score 78, 9 assignments completed, and 7 sleep hours. The latest verified model prediction is **63.65**.

## Generated Outputs

- `outputs/test_predictions.csv`
- `outputs/metrics.json`
- `outputs/example_prediction.json`
- `outputs/actual_vs_predicted.png`

## Model Result

![Actual vs Predicted](./outputs/actual_vs_predicted.png)

## Project Structure

```text
student-score-prediction-sklearn/
├── data/
│   └── student_scores.csv
├── src/
│   ├── __init__.py
│   ├── data.py
│   ├── model.py
│   └── evaluation.py
├── tests/
│   └── test_pipeline.py
├── outputs/
│   ├── test_predictions.csv
│   ├── metrics.json
│   ├── example_prediction.json
│   └── actual_vs_predicted.png
├── screenshots/
│   └── .gitkeep
├── main.py
├── requirements.txt
├── .gitignore
└── README.md
```

## Testing

Run:

```powershell
pytest -q
```

The latest verified execution passed **8 tests**.

## Getting Started

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python main.py
pytest -q
```

## Screenshots

### Data Exploration

![Data Exploration](./screenshots/data-exploration.png)

### Model Evaluation

![Model Evaluation](./screenshots/model-evaluation.png)

### Example Prediction

![Example Prediction](./screenshots/example-prediction.png)

The screenshot placeholders above are intended for manual terminal captures; no fake screenshots are included.

## Limitations

- The dataset is synthetic and small.
- Linear Regression is the only model.
- There is no hyperparameter tuning or cross-validation.
- Results are educational and are not appropriate for real educational decisions.

## Project Scope

The Mini Project intentionally excludes notebooks, deployment APIs, web interfaces, databases, complex feature engineering, model comparison, and model serialization. The focus is a readable baseline ML workflow using scripts and saved evaluation artifacts.

## Educational Disclaimer

This project uses synthetic data and is intended only for machine-learning practice. It should not be used for student grading, admissions, ranking, or other real educational decisions.
