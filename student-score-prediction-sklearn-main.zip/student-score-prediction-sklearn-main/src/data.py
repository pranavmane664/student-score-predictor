"""Dataset loading, validation, exploration, and splitting utilities."""

from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

FEATURE_COLUMNS = [
    "study_hours_per_week",
    "attendance_percentage",
    "previous_exam_score",
    "assignments_completed",
    "sleep_hours",
]
TARGET_COLUMN = "final_score"
IDENTIFIER_COLUMN = "student_id"
REQUIRED_COLUMNS = [IDENTIFIER_COLUMN, *FEATURE_COLUMNS, TARGET_COLUMN]


def load_dataset(path: Path) -> pd.DataFrame:
    """Load and validate the student score CSV."""
    dataframe = pd.read_csv(path)
    validate_dataset(dataframe)
    return dataframe


def validate_dataset(dataframe: pd.DataFrame) -> None:
    """Raise a clear error when the expected schema or target is invalid."""
    missing_columns = sorted(set(REQUIRED_COLUMNS) - set(dataframe.columns))
    if missing_columns:
        raise ValueError(
            f"Dataset is missing required columns: {', '.join(missing_columns)}"
        )
    if dataframe[TARGET_COLUMN].isna().any():
        raise ValueError("Dataset target 'final_score' contains missing values.")


def explore_dataset(dataframe: pd.DataFrame) -> dict:
    """Return basic exploration values for readable console reporting."""
    return {
        "rows": len(dataframe),
        "columns": len(dataframe.columns),
        "duplicates": int(dataframe.duplicated().sum()),
        "missing_values": dataframe.isna().sum(),
        "dtypes": dataframe.dtypes,
        "head": dataframe.head(),
        "numeric_summary": dataframe.describe(include="number").round(2),
    }


def clean_dataset(dataframe: pd.DataFrame) -> pd.DataFrame:
    """Remove exact duplicate rows without imputing feature values."""
    validate_dataset(dataframe)
    return dataframe.drop_duplicates().reset_index(drop=True)


def split_dataset(
    dataframe: pd.DataFrame, test_size: float = 0.2, random_state: int = 42
) -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series, pd.Series, pd.Series]:
    """Split the five features and target while retaining test identifiers."""
    validate_dataset(dataframe)
    features = dataframe[FEATURE_COLUMNS]
    target = dataframe[TARGET_COLUMN]
    identifiers = dataframe[IDENTIFIER_COLUMN]
    return train_test_split(
        features,
        target,
        identifiers,
        test_size=test_size,
        random_state=random_state,
    )
