"""Student Score Predictor package."""
