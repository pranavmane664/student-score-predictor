"""Linear regression pipeline construction and prediction helpers."""

import pandas as pd
from numpy.typing import NDArray
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline


def build_pipeline() -> Pipeline:
    """Build the intentionally simple baseline regression pipeline."""
    return Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("regressor", LinearRegression()),
        ]
    )


def train_model(X_train: pd.DataFrame, y_train: pd.Series) -> Pipeline:
    """Fit a fresh pipeline on training data only."""
    model = build_pipeline()
    model.fit(X_train, y_train)
    return model


def predict(model: Pipeline, features: pd.DataFrame) -> NDArray:
    """Predict scores through the complete fitted pipeline."""
    return model.predict(features)
