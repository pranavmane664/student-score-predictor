"""Evaluation and portfolio artifact writers."""

import json
import os
import tempfile
from pathlib import Path

os.environ.setdefault(
    "MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "student-score-predictor-matplotlib")
)

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def calculate_metrics(actual, predicted) -> dict[str, float]:
    """Calculate the three regression metrics used by this Mini Project."""
    return {
        "mae": float(mean_absolute_error(actual, predicted)),
        "mse": float(mean_squared_error(actual, predicted)),
        "r2_score": float(r2_score(actual, predicted)),
    }


def build_predictions_dataframe(
    student_ids, actual, predicted
) -> pd.DataFrame:
    """Create a transparent row-level comparison of test predictions."""
    actual_array = np.asarray(actual, dtype=float)
    predicted_array = np.asarray(predicted, dtype=float)
    return pd.DataFrame(
        {
            "student_id": np.asarray(student_ids),
            "actual_score": np.round(actual_array, 2),
            "predicted_score": np.round(predicted_array, 2),
            "absolute_error": np.round(np.abs(actual_array - predicted_array), 2),
        }
    )


def save_metrics(metrics: dict[str, float], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rounded = {key: round(value, 6) for key, value in metrics.items()}
    path.write_text(json.dumps(rounded, indent=2) + "\n", encoding="utf-8")


def save_predictions(predictions: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    predictions.to_csv(path, index=False)


def save_example_prediction(
    example_input: dict[str, float], prediction: float, path: Path
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "input": example_input,
        "predicted_final_score": round(float(prediction), 6),
    }
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def save_actual_vs_predicted_plot(
    actual, predicted, path: Path
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    actual_array = np.asarray(actual, dtype=float)
    predicted_array = np.asarray(predicted, dtype=float)
    bounds = [
        min(actual_array.min(), predicted_array.min()),
        max(actual_array.max(), predicted_array.max()),
    ]
    figure, axis = plt.subplots(figsize=(8, 6))
    axis.scatter(actual_array, predicted_array, alpha=0.75)
    axis.plot(bounds, bounds, linestyle="--", color="black", label="Perfect prediction")
    axis.set_title("Actual vs Predicted Student Scores")
    axis.set_xlabel("Actual Final Score")
    axis.set_ylabel("Predicted Final Score")
    axis.legend()
    figure.tight_layout()
    figure.savefig(path, dpi=150)
    plt.close(figure)
