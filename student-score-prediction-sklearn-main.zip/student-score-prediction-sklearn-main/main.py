"""Command-line entry point for the Student Score Predictor Mini Project."""

from pathlib import Path

import pandas as pd

from src.data import FEATURE_COLUMNS, clean_dataset, explore_dataset, load_dataset, split_dataset
from src.evaluation import (
    build_predictions_dataframe,
    calculate_metrics,
    save_actual_vs_predicted_plot,
    save_example_prediction,
    save_metrics,
    save_predictions,
)
from src.model import predict, train_model

PROJECT_ROOT = Path(__file__).resolve().parent
DATA_PATH = PROJECT_ROOT / "data" / "student_scores.csv"
OUTPUTS_PATH = PROJECT_ROOT / "outputs"
EXAMPLE_INPUT = {
    "study_hours_per_week": 14,
    "attendance_percentage": 92,
    "previous_exam_score": 78,
    "assignments_completed": 9,
    "sleep_hours": 7,
}


def section(number: int, title: str) -> None:
    print(f"\n[{number}] {title}")
    print("-" * 40)


def main() -> None:
    print("=" * 40)
    print("STUDENT SCORE PREDICTION")
    print("=" * 40)

    section(1, "Loading Dataset")
    dataframe = load_dataset(DATA_PATH)
    print(f"Dataset loaded successfully: {DATA_PATH.relative_to(PROJECT_ROOT)}")

    section(2, "Data Exploration")
    exploration = explore_dataset(dataframe)
    print(f"Rows       : {exploration['rows']}")
    print(f"Columns    : {exploration['columns']}")
    print(f"Duplicates : {exploration['duplicates']}")
    print("\nMissing Values:")
    print(exploration["missing_values"].to_string())
    print("\nColumn Types:")
    print(exploration["dtypes"].to_string())
    print("\nFirst 5 Rows:")
    print(exploration["head"].to_string(index=False))
    print("\nNumeric Summary:")
    print(exploration["numeric_summary"].to_string())

    section(3, "Preprocessing")
    clean_data = clean_dataset(dataframe)
    X_train, X_test, y_train, y_test, _, test_ids = split_dataset(clean_data)
    print(f"Duplicates removed : {len(dataframe) - len(clean_data)}")
    print(f"Features selected  : {len(FEATURE_COLUMNS)}")
    print(f"Training samples   : {len(X_train)}")
    print(f"Testing samples    : {len(X_test)}")

    section(4, "Training Model")
    model = train_model(X_train, y_train)
    print("Model            : Linear Regression")
    print("Training status  : Completed")

    test_predictions = predict(model, X_test)
    metrics = calculate_metrics(y_test, test_predictions)
    section(5, "Model Evaluation")
    print(f"MAE      : {metrics['mae']:.4f}")
    print(f"MSE      : {metrics['mse']:.4f}")
    print(f"R2 Score : {metrics['r2_score']:.4f}")

    example_frame = pd.DataFrame([EXAMPLE_INPUT], columns=FEATURE_COLUMNS)
    example_prediction = float(predict(model, example_frame)[0])
    section(6, "Example Prediction")
    print("Study Hours / Week     : 14")
    print("Attendance             : 92%")
    print("Previous Exam Score    : 78")
    print("Assignments Completed  : 9")
    print("Sleep Hours            : 7")
    print(f"\nPredicted Final Score  : {example_prediction:.2f}")

    prediction_rows = build_predictions_dataframe(test_ids, y_test, test_predictions)
    output_files = {
        "test_predictions.csv": OUTPUTS_PATH / "test_predictions.csv",
        "metrics.json": OUTPUTS_PATH / "metrics.json",
        "example_prediction.json": OUTPUTS_PATH / "example_prediction.json",
        "actual_vs_predicted.png": OUTPUTS_PATH / "actual_vs_predicted.png",
    }
    save_predictions(prediction_rows, output_files["test_predictions.csv"])
    save_metrics(metrics, output_files["metrics.json"])
    save_example_prediction(
        EXAMPLE_INPUT, example_prediction, output_files["example_prediction.json"]
    )
    save_actual_vs_predicted_plot(
        y_test, test_predictions, output_files["actual_vs_predicted.png"]
    )

    section(7, "Saving Results")
    for relative_name in output_files:
        print(f"Saved: outputs/{relative_name}")
    print("\nDone.")


if __name__ == "__main__":
    main()
